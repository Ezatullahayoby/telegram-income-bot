const TelegramBot = require('node-telegram-bot-api');
const db = require('./db');
const token = '7862169660:AAEvDnT3joyO224IVPSF9XHYjPNaiYxVLLs';
const bot = new TelegramBot(token, { polling: true });

const botUsername = 'Free_money_Af_bot';
const requiredChannels = ['@free_money_af', '@free_money_af0'];
const adminId = 123456789; // ← آیدی عددی مدیر ربات را اینجا وارد کن

// منوی اصلی
const mainMenu = {
  reply_markup: {
    inline_keyboard: [
      [{ text: '📊 داشبورد من', callback_data: 'dashboard' }],
      [{ text: '🔗 لینک دعوت من', callback_data: 'invite' }],
      [{ text: '💰 درخواست برداشت', callback_data: 'withdraw' }]
    ]
  }
};

// دکمه‌های عضویت در کانال‌ها
const joinButtons = {
  reply_markup: {
    inline_keyboard: [
      [
        { text: '📢 عضویت در کانال 1', url: 'https://t.me/free_money_af' },
        { text: '📢 عضویت در کانال 2', url: 'https://t.me/free_money_af0' }
      ],
      [{ text: '🔄 بررسی عضویت', callback_data: 'check_join' }]
    ]
  }
};

// دکمه برگشت به منو
const backButton = {
  reply_markup: {
    inline_keyboard: [
      [{ text: '🔙 برگشت به منوی اصلی', callback_data: 'back_to_menu' }]
    ]
  }
};

// بررسی عضویت در همه کانال‌ها
async function isUserJoinedAll(userId) {
  for (const channel of requiredChannels) {
    try {
      const member = await bot.getChatMember(channel, userId);
      if (['left', 'kicked'].includes(member.status)) {
        return false;
      }
    } catch (e) {
      return false;
    }
  }
  return true;
}

// ورود کاربر
bot.onText(/\/start(?:\s+(\d+))?/, async (msg, match) => {
  const userId = msg.from.id;
  const username = msg.from.username || 'بدون نام';
  const inviterId = match[1];

  const joined = await isUserJoinedAll(userId);

  if (!joined) {
    let message = `سلام ${username} عزیز 👋\nبرای استفاده از ربات، ابتدا باید عضو کانال‌های زیر شوید:\n\n`;
    message += `📢 @free_money_af\n📢 @free_money_af0\n\nبعد از عضویت، روی دکمه «🔄 بررسی عضویت» کلیک کنید.`;
    bot.sendMessage(userId, message, joinButtons);
    return;
  }

  db.get('SELECT * FROM users WHERE user_id = ?', [userId], (err, row) => {
    if (!row) {
      db.run('INSERT INTO users (user_id, username, invited_by) VALUES (?, ?, ?)', [userId, username, inviterId]);
      if (inviterId && inviterId !== userId) {
        db.run('UPDATE users SET balance = balance + 10, invite_count = invite_count + 1 WHERE user_id = ?', [inviterId]);
        bot.sendMessage(inviterId, `🎉 یک نفر جدید با لینک شما وارد شد!\n💰 ۱۰ افغانی به حساب شما اضافه شد.`);
      }
    }
  });

  bot.sendMessage(userId, `✅ عضویت شما تأیید شد!\nاز منوی زیر استفاده کنید:`, mainMenu);
});

// مدیریت دکمه‌ها
bot.on('callback_query', async (query) => {
  const userId = query.from.id;
  const data = query.data;
  const chatId = query.message.chat.id;
  const messageId = query.message.message_id;

  if (data === 'check_join') {
    const joined = await isUserJoinedAll(userId);
    if (joined) {
      bot.editMessageText('✅ عضویت شما تأیید شد! حالا می‌تونید از ربات استفاده کنید:', {
        chat_id: chatId,
        message_id: messageId,
        reply_markup: mainMenu.reply_markup
      });
    } else {
      bot.editMessageText('❌ هنوز عضو همه کانال‌ها نیستید. لطفاً عضو شوید و دوباره بررسی کنید:', {
        chat_id: chatId,
        message_id: messageId,
        reply_markup: joinButtons.reply_markup
      });
    }
    return;
  }

  if (data === 'dashboard') {
    db.get('SELECT balance, invite_count FROM users WHERE user_id = ?', [userId], (err, row) => {
      const balance = row?.balance || 0;
      const invites = row?.invite_count || 0;
      const message = `📊 داشبورد شما:\n\n👥 تعداد دعوت‌شدگان: ${invites}\n💰 موجودی: ${balance} افغانی\n\nبرای برداشت باید حداقل ۵۰۰ افغانی داشته باشید.`;
      bot.editMessageText(message, {
        chat_id: chatId,
        message_id: messageId,
        reply_markup: backButton.reply_markup
      });
    });
  }

  if (data === 'invite') {
    const link = `https://t.me/${botUsername}?start=${userId}`;
    const message = `🔗 لینک دعوت شما:\n${link}\n\n📤 این لینک را برای دوستان خود ارسال کنید تا درآمد کسب کنید.`;
    bot.editMessageText(message, {
      chat_id: chatId,
      message_id: messageId,
      reply_markup: backButton.reply_markup
    });
  }

  if (data === 'withdraw') {
    db.get('SELECT balance FROM users WHERE user_id = ?', [userId], (err, row) => {
      const balance = row?.balance || 0;
      let message;
      if (balance >= 500) {
        const date = new Date().toLocaleString('fa-AF');
        db.run('INSERT INTO withdraw_requests (user_id, amount, request_date) VALUES (?, ?, ?)', [userId, balance, date]);
        db.run('UPDATE users SET balance = 0 WHERE user_id = ?', [userId]);
        message = '📤 درخواست برداشت شما ثبت شد و در حال بررسی است.';
        bot.editMessageText(message, {
          chat_id: chatId,
          message_id: messageId,
          reply_markup: backButton.reply_markup
        });

        // ارسال ثبوت برداشت به کانال
        const proofMessage = `✅ برداشت ثبت شد:\n👤 کاربر: ${userId}\n💰 مبلغ: ${balance} افغانی\n📅 زمان: ${date}\n📌 وضعیت: در انتظار بررسی`;
        bot.sendMessage('@free_money_af0', proofMessage);
      } else {
        message = '❌ موجودی شما برای برداشت کافی نیست. حداقل ۵۰۰ افغانی لازم است.';
        bot.editMessageText(message, {
          chat_id: chatId,
          message_id: messageId,
          reply_markup: backButton.reply_markup
        });
      }
    });
  }

  if (data === 'back_to_menu') {
    bot.editMessageText('🔙 بازگشت به منوی اصلی:', {
      chat_id: chatId,
      message_id: messageId,
      reply_markup: mainMenu.reply_markup
    });
  }
});

// دستور مدیر برای افزودن دستی موجودی
bot.onText(/\/addbalance (\d+) (\d+)/, (msg, match) => {
  const senderId = msg.from.id;
  if (senderId !== adminId) {
    bot.sendMessage(senderId, '❌ فقط مدیر اجازه دارد از این دستور استفاده کند.');
    return;
  }

  const targetId = parseInt(match[1]);
  const amount = parseInt(match[2]);

  db.get('SELECT * FROM users WHERE user_id = ?', [targetId], (err, row) => {
    if (!row) {
      bot.sendMessage(senderId, `❌ کاربری با آیدی ${targetId} یافت نشد.`);
    } else {
      db.run('UPDATE users SET balance = balance + ? WHERE user_id = ?', [amount, targetId]);
      bot.sendMessage(senderId, `✅ مبلغ ${amount} افغانی به حساب کاربر ${targetId} اضافه شد.`);

      // اطلاع‌رسانی به کانال
      const notify = `💳 افزودن دستی موجودی:\n👤 کاربر: ${targetId}\n➕ مبلغ: ${amount} افغانی\n👮‍♂️ توسط مدیر`;
      bot.sendMessage('@free_money_af0', notify);
    }
  });
});
